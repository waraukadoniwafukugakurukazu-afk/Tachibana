
const DEFAULT_DATA = {
  intro:"九州国際大学の大学祭「橘祭」。学生と地域がつながり、ステージ・出店・企画を楽しめる2日間です。",
  day1:"1日目", day2:"2日目",
  images:{campusMap:"",insideMap:"",stageSchedule:"",shopMap:""},
  stages:[
    {id:"s1",day:1,name:"ステージ情報は準備中です",time:"時間未定",join:true},
    {id:"s2",day:2,name:"ステージ情報は準備中です",time:"時間未定",join:true}
  ],
  shops:[{id:"p1",no:"01",name:"出店情報は準備中です",sell:"内容は後日公開"}]
};
function loadData(){
  try{return {...DEFAULT_DATA,...JSON.parse(localStorage.getItem("tachibanaData")||"{}")}}
  catch(e){return structuredClone(DEFAULT_DATA)}
}
function saveData(d){localStorage.setItem("tachibanaData",JSON.stringify(d))}
function esc(s=""){return String(s).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#039;"}[m]))}
function imgHTML(src,alt){
  return src ? `<img src="${src}" alt="${esc(alt)}">` : `<span>管理画面から画像を追加できます</span>`;
}
function runSearch(inputId, selector){
  const q=document.getElementById(inputId).value.trim().toLowerCase();
  document.querySelectorAll(selector).forEach(el=>el.classList.remove("hit"));
  if(!q)return;
  const found=[...document.querySelectorAll(selector)].find(el=>el.innerText.toLowerCase().includes(q));
  if(found){found.classList.add("hit");found.scrollIntoView({behavior:"smooth",block:"center"});}
  else alert("一致する情報が見つかりませんでした");
}
